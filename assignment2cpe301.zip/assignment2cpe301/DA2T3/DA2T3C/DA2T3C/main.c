/*
 * DA2T3C.c
 *
 * Created: 3/15/2018 1:00:49 PM
 * Author : Kengneta
 */ 


#include <avr/io.h>
#include <avr/delay.h>

int main(void)
{
	DDRB = 32;		//set PORTB 5 to output
	TCCR0B = 5;	//set prescaler to 1024
	TCNT0 = 0;		//set TCNT to 0
	OCR0A = 0x00F3;	//set max value to F3
	
	while (1)
	{
		if(TCNT0 >=255) 	//check for overflow
		{
			PORTB = 0xFF;		//set PORTB to FF
			_delay_ms(250);		//delay for 250ms
			PORTB = 0x00;		//set PORTB to 0
			TCNT0 = 0;			//reset counter to 0
			
		}
	}
}
