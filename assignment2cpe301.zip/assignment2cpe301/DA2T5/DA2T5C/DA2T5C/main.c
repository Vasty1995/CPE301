/*
 * DA2T5C.c
 *
 * Created: 3/15/2018 1:06:54 PM
 * Author : Kengneta
 */ 

#include <avr/io.h>


#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

ISR(INT0_vect)
{
	
	PORTB = 0xFF;    // toggle LED
	_delay_ms(1000);
	PORTB = 0;
}
int main()
{
	DDRB = 0x04;
	EIMSK = 0X01;
	EIFR = 0X01;
	EICRA = 0X03;
	sei();
	
	while(1) {}
}