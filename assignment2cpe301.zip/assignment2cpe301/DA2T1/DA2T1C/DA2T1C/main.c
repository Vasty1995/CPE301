/*
 * DA2T1C.c
 *
 * Created: 3/15/2018 12:52:00 PM
 * Author : Kengneta
 */ 

#include <avr/io.h>


int main()
{
	DDRB = 0b00000100;
	PORTB = 0x00;
	TCCR1B = 5;         // set prescaler to 1024
	while(1) {
		if(TCNT1 == 0x01E7){
			PORTB ^= 0b00000100;
			TCNT1 = 0x00;
		}
	}
}